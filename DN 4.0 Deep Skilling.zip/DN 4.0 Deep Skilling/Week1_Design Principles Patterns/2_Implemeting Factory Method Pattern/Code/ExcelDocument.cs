using System;

public class ExcelDocument : Document
{
    public void creating()
    {
        Console.WriteLine("Creating a ExcelDocument");
    }

    public void opening()
    {
        Console.WriteLine("Opeing a ExcelDocument");
    }

    public void saveing()
    {
        Console.WriteLine("Saving a ExcelDocument");
    }

    public void closing()
    {
        Console.WriteLine("Closing a ExcelDocument");
    }
}
