using System;

public class WordDocument : Document
{
    public void creating()
    {
        Console.WriteLine("Creating a WordDocument");
    }

    public void opening()
    {
        Console.WriteLine("Opeing a WordDocument");
    }

    public void saveing()
    {
        Console.WriteLine("Saving a WordDocument");
    }

    public void closing()
    {
        Console.WriteLine("Closing a WordDocument");
    }
}
