public interface Document
{
    void creating();
    void opening();
    void saveing();
    void closing();
}
